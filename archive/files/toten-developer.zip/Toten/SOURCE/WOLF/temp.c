{
        VW_FadeOut();

	CA_CacheGrChunk (PG13PIC);
        CA_CacheGrChunk (C_TIMECODEPIC);
        VWB_DrawPic (0,0,PG13PIC);
        VWB_DrawPic (0,96,C_TIMECODEPIC);
	VW_UpdateScreen ();

        UNCACHEGRCHUNK (PG13PIC);
        UNCACHEGRCHUNK (C_TIMECODEPIC);

        VW_FadeIn();
        IN_UserInput(TickBase*12);

        VW_FadeOut ();
}
